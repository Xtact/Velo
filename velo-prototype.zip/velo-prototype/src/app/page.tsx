'use client';

import VELOApp from '@/components/VELOApp';

export default function Home() {
  return <VELOApp />;
}
